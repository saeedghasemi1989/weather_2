﻿var cel = true;
var lat = "35.6944";
var lng = "51.4215";
var cityName = "تهران";
var unit = "si";
var apiUrl = "https://api.openweathermap.org/data/2.5/forecast";
var appid = "2a47a80c223baab80003883c31f35729";
var wd;
var settings;
var lat;
var lng;
var skycons;
var localStorageVaribleName;

//get weather summary 

function getDarkskyData() {
  $.ajax({
    url: apiUrl,
    data: {
      lat: lat,
      lon: lng,
      limit: "5",
      units: "metric",
      appid: appid
    },
    type: "GET",
    error: function (error) {

    },
    success: function (data) {
      handleData(data);
      setCurrentWeather();
      setDailyWeather();
      setLocalStorage(data);
    }
  });
}

var maxt_1 = -250;
var mint_1 = 100;
var maxt_2 = -250;
var mint_2 = 100;
var maxt_3 = -250;
var mint_3 = 100;
var maxt_4 = -250;
var mint_4 = 100;
var maxt_5 = -250;
var mint_5 = 100;
var d_1 = new Date();
let nowHours = d_1.getHours();
var d_2 = new Date();
var d_3 = new Date();
var d_4 = new Date();
var d_5 = new Date();
let status1 = null;
let status2 = null;
let status3 = null;
let status4 = null;
let status5 = null;
let chartTempThreeHours = [];
let chartTempThreeHours_min = [];
let chartTempThreeHours_middle = [];
let chartTempThreeHours_hours = [];
let chartTempThreeHours_max = [];


function handleData(data) {

  maxt_1 = -250;
  mint_1 = 1000;
  maxt_2 = -250;
  mint_2 = 1000;
  maxt_3 = -250;
  mint_3 = 1000;
  maxt_4 = -250;
  mint_4 = 1000;
  maxt_5 = -250;
  mint_5 = 1000;
  d_2.setDate(d_2.getDate() + 1);
  d_3.setDate(d_3.getDate() + 2);
  d_4.setDate(d_4.getDate() + 3);
  d_5.setDate(d_5.getDate() + 4);
  d_1 = d_1.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
  d_2 = d_2.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
  d_3 = d_3.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
  d_4 = d_4.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
  d_5 = d_5.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });

  for (let i = 0; i < data.list.length; i++) {
    //date with clock
    let d = new Date(data.list[i].dt_txt);
    //hours at all day
    let itemHours = d.getHours();
    //date
    d = d.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    let tMin = data.list[i].main.temp_min;
    let tMax = data.list[i].main.temp_max;



    if (d === d_1) {
      //just today
      if (maxt_1 < tMax) {
        maxt_1 = tMax;
      }
      if (mint_1 > tMin) {
        mint_1 = tMin;
      }

      if (itemHours <= nowHours && (itemHours + 3) > nowHours) {
        status1 = data.list[i].weather[0].description;
      }

    }

    if (d === d_2) {
      if (maxt_2 < tMax) {
        maxt_2 = tMax;
      }
      if (mint_2 > tMin) {
        mint_2 = tMin;
      }

      if (itemHours == 9) {
        status2 = data.list[i].weather[0].description;
      }
    }

    if (d === d_3) {
      if (maxt_3 < tMax) {
        maxt_3 = tMax;
      }
      if (mint_3 > tMin) {
        mint_3 = tMin;
      }

      if (itemHours == 9) {
        status3 = data.list[i].weather[0].description;
      }
    }

    if (d === d_4) {
      if (maxt_4 < tMax) {
        maxt_4 = tMax;
      }
      if (mint_4 > tMin) {
        mint_4 = tMin;
      }


      if (itemHours == 9) {
        status4 = data.list[i].weather[0].description;
      }
    }

    if (d === d_5) {
      if (maxt_5 < tMax) {
        maxt_5 = tMax;
      }
      if (mint_5 > tMin) {
        mint_5 = tMin;
      }


      if (itemHours == 9) {
        status5 = data.list[i].weather[0].description;
      }
    }


  }


  let dateChart = new Date();
  for (let i = 0; i < data.list.length; i++) {
    let itemDate = new Date(data.list[i].dt_txt);
    if (itemDate > dateChart) {
      if (chartTempThreeHours.length < 8) {
        chartTempThreeHours_min.push(data.list[i].main.temp_min);
        chartTempThreeHours_max.push(data.list[i].main.temp_max);
        chartTempThreeHours_middle.push(data.list[i].main.temp);
        let obj = [data.list[i].main.temp_min, data.list[i].main.temp_max];
        chartTempThreeHours.push(obj);
        chartTempThreeHours_hours.push(itemDate.getHours() + ":00");



      }
    }
  }
  lineChart();

}



function getWeatherDescription(desc) {
  try {
    desc = desc.toLowerCase();
    if (desc.includes("clear sky"))
      out = "آسمان صاف";
    else if (desc.includes("few clouds"))
      out = "آفتابی همراه با ابر";
    else if (desc.includes("scattered clouds"))
      out = "ابرهای پراکنده";
    else if (desc.includes("broken clouds"))
      out = "ابری";
    else if (desc.includes("overcast clouds"))
      out = "ابری";
    else if (desc.includes("light rain"))
      out = "باران سبک";
    else if (desc.includes("moderate rain"))
      out = "باران";
    else if (desc.includes("heavy intensity rain"))
      out = "باران شدید";
    else if (desc.includes("very heavy rain"))
      out = "باران شدید";
    else if (desc.includes("extreme rain"))
      out = "باران شدید";
    else if (desc.includes("freezing rain"))
      out = "باران";
    else if (desc.includes("light intensity shower rain"))
      out = "باران شدید";
    else if (desc.includes("heavy intensity shower rain"))
      out = "باران شدید";
    else if (desc.includes("ragged shower rain"))
      out = "باران شدید";
    else if (desc.includes("shower rain"))
      out = "بارش باران";
    else if (desc.includes(desc === "light snow"))
      out = "تگرگ";
    else if (desc.includes(desc === "Heavy snow"))
      out = "تگرگ";
    else if (desc.includes(desc === "Light shower sleet"))
      out = "تگرگ";
    else if (desc.includes(desc === "Shower sleet"))
      out = "بارش تگرگ";
    else if (desc.includes(desc === "Sleet"))
      out = "تگرگ";
    else if (desc.includes(desc === "Light rain and snow"))
      out = "باران سبک و برف";
    else if (desc.includes(desc === "Rain and snow"))
      out = "برف و باران";
    else if (desc.includes(desc === "Light shower snow"))
      out = "بارش سبک برف";
    else if (desc.includes(desc === "Heavy shower snow"))
      out = "بارش سنگین برف";
    else if (desc.includes(desc === "Shower snow"))
      out = "بارش برف";
    else if (desc.includes(desc === "mist"))
      out = "مه";
    else if (desc.includes(desc === "Smoke"))
      out = "غبار و دود";
    else if (desc.includes(desc === "Haze"))
      out = "مه";
    else if (desc.includes(desc === "sand / dust whirls"))
      out = "گردو غبار/ شن";
    else if (desc.includes(desc === "fog"))
      out = "مه";
    else if (desc.includes(desc === "sand"))
      out = "شن";
    else if (desc.includes(desc === "dust"))
      out = "گرد و خاک";
    else if (desc.includes(desc === "volcanic ash"))
      out = "خاکستر آتشفشانی";
    else if (desc.includes(desc === "squalls"))
      out = "باد شدید";
    else if (desc.includes(desc === "tornado"))
      out = "گردباد";
    else if (desc.includes(desc === "light intensity drizzle"))
      out = "نم نم باران";
    else if (desc.includes(desc === "heavy intensity drizzle"))
      out = "نم نم باران";
    else if (desc.includes(desc === "light intensity drizzle rain"))
      out = "نم نم باران";
    else if (desc.includes(desc === "heavy intensity drizzle rain"))
      out = "نم نم باران";
    else if (desc.includes(desc === "shower rain and drizzle"))
      out = "نم نم باران";
    else if (desc.includes(desc === "heavy shower rain and drizzle"))
      out = "نم نم باران";
    else if (desc.includes(desc === "shower drizzle"))
      out = "نم نم باران";
    else if (desc.includes(desc === "drizzle rain"))
      out = "نم نم باران";
    else if (desc.includes(desc === "thunderstorm with light rain"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "thunderstorm with rain"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "thunderstorm with heavy rain"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "light thunderstorm"))
      out = "رعد و برق";
    else if (desc.includes(desc === "heavy thunderstorm"))
      out = "رعد و برق";
    else if (desc.includes(desc === "ragged thunderstorm"))
      out = "رعد و برق";
    else if (desc.includes(desc === "thunderstorm with light drizzle"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "thunderstorm with drizzle"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "thunderstorm with heavy drizzle"))
      out = "رعد و برق همراه باران";
    else if (desc.includes(desc === "drizzle"))
      out = "نم نم باران";
    else if (desc.includes("snow"))
      out = "برفی";
    else if (desc.includes("thunderstorm"))
      out = "رعد و برق";
    else if (desc.includes("mist"))
      out = "مه";
    else if (desc.includes("rain"))
      out = "باران";
    else if (desc.includes("cloud"))
      out = "ابر";

    else if (desc === "partly sunny")
      out = "کمی آفتابی";
    else if (desc === "scattered thunderstorms")
      out = "رعد و برق پراکنده";
    else if (desc == "showers")
      out = "رگبار";
    else if (desc == "scattered showers")
      out = "رگبار پراکنده";
    else if (desc === "rain and snow")
      out = "برف و باران";
    else if (desc == "overcast")
      out = "ابری";
    else if (desc == "light snow")
      out = "برف سبک";
    else if (desc == "freezing drizzle")
      out = "نم نم باران";
    else if (desc == "chance of Rain")
      out = "احتمال بارندگی";
    else if (desc == "sunny")
      out = "آفتابی";
    else if (desc == "clear")
      out = "آسمان صاف";
    else if (desc == "mostly sunny")
      out = "آفتابی";
    else if (desc == "partly cloudy")
      out = "نیمه ابری";
    else if (desc == "mostly cloudy")
      out = "ابری";
    else if (desc == "chance of storm")
      out = "احتمال طوفان";
    else if (desc == "rain")
      out = "بارانی";
    else if (desc == "chance of snow")
      out = "احتمال برف";
    else if (desc == "cloudy")
      out = "ابری";
    else if (desc == "mist")
      out = "غبار محلی";
    else if (desc == "storm")
      out = "طوفانی";
    else if (desc == "thunderstorm")
      out = "رعد و برق";
    else if (desc == "chance of tstorm" || desc === "chance of storm")
      out = "احتمال طوفان";
    else if (desc == "sleet")
      out = "بوران";
    else if (desc == "snow")
      out = "برفی";
    else if (desc == "icy")
      out = "یخ زده";
    else if (desc == "dust")
      out = "گرد و غبار";
    else if (desc == "fog")
      out = "مه";
    else if (desc == "smoke")
      out = "دود ";
    else if (desc == "haze")
      out = "غبار مه";
    else if (desc == "flurries")
      out = "طوفان ناگهانی";
    else if (desc == "light rain")
      out = "باران سبک";
    else if (desc == "snow showers")
      out = "بارش شدید برف";
    else if (desc == "hail")
      out = "تگرگ";
    else
      out = "";
    return out;
  } catch (e) { }
}

function getWeatherIcon(str) {
  var icon = "partly-cloudy-day";
  try {
    str = str.toLowerCase().trim();
    if (str.includes("clear")) {
      icon = "clear-day";
    }
    else if (str.includes("few clouds")) {
      icon = "partly-cloudy-day";
    }
    else if (str.includes("broken clouds")) {
      icon = "partly-cloudy-day";
    }
    else if (str.includes("clouds")) {
      icon = "cloudy";
    }
    else if (str.includes("rain")) {
      icon = "rain";
    }
    else if (str.includes("snow")) {
      icon = "snow";
    }
    else if (str.includes("thunderstorm")) {
      icon = "wind";
    }
    else if (str.includes("mist")) {
      icon = "fog";
    }
  } catch (e) { }
  return icon;
}


function setCurrentWeather() {
  var icon = getWeatherIcon(status1);
  var cond = getWeatherDescription(status1);
  //var temp = data.currently.temperature;
  var temp_max = Math.round(maxt_1) + "°";
  var temp_min = Math.round(mint_1) + "°";
  var tmp = temp_max + " / " + temp_min;
  //var temp_f = Math.round(temp) + "℃";
  // $("#today_temp").text(temp_f);
  $("#today_temp").text(tmp);
  $("#today_condition").text(cond);
  skycons.add('icon1', icon);
  skycons.play();

}

function setDailyWeather() {

  var temp_max = Math.round(maxt_2) + "°";
  var temp_min = Math.round(mint_2) + "°";
  var tmp = temp_max + " / " + temp_min;
  var day_icon = getWeatherIcon(status2);
  document.getElementById('day1_temp').innerText += tmp;
  skycons.add('day_icon1', day_icon);

  temp_max = Math.round(maxt_3) + "°";
  temp_min = Math.round(mint_3) + "°";
  tmp = temp_max + " / " + temp_min;
  day_icon = getWeatherIcon(status3);
  document.getElementById('day2_temp').innerText += tmp;
  skycons.add('day_icon2', day_icon);

  temp_max = Math.round(maxt_4) + "°";
  temp_min = Math.round(mint_4) + "°";
  tmp = temp_max + " / " + temp_min;
  day_icon = getWeatherIcon(status4);
  document.getElementById('day3_temp').innerText += tmp;
  skycons.add('day_icon3', day_icon);


  temp_max = Math.round(maxt_5) + "°";
  temp_min = Math.round(mint_5) + "°";
  tmp = temp_max + " / " + temp_min;
  day_icon = getWeatherIcon(status5);
  document.getElementById('day4_temp').innerText += tmp;
  skycons.add('day_icon4', day_icon);

  skycons.play();
}

function getIcon(icon, iconID) {
  var weather = ["clear-day", "clear-night", "rain", "snow", "sleet", "wind", "fog", "cloudy", "partly-cloudy-day", "partly-cloudy-night"];
  var currentIcon = icon.replace(/-/g, '_').toUpperCase();
  return skycons.set(iconID, Skycons[currentIcon]);
}

function setLocalStorage(weatherData) {
  var expireDate = new Date();
  expireDate = expireDate.getTime() + (1 * 24 * 60 * 60 * 1000);//expire after one day
  weatherData.expireDate = expireDate;
  var data = JSON.stringify(weatherData);
  // Storage     
  localStorage.setItem(localStorageVaribleName, data);

}

function checkCookie(storageName) {
  var weather_data = localStorage.getItem(storageName); //get weather coocki data
  if (weather_data != "") {
    if (!isDataExpired(weather_data)) {
      handleData(JSON.parse(weather_data));
      setCurrentWeather(JSON.parse(weather_data)); //set news
      setDailyWeather(JSON.parse(weather_data))
    }
    else {
      getDarkskyData();
    }
  } else {
    getDarkskyData();
  }
}

function isDataExpired(weather_data) {
  try {
    var j = JSON.parse(weather_data);
    if (j.expireDate) {
      var expireDate = new Date();
      var nowTime = expireDate.getTime();
      if (j.expireDate > nowTime) {
        return false;
      }
    }
  } catch (error) { }
  return true;
}

function deleteCookie(name) {
  document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function eraseCookie(name) {
  setCookie(name, "", -1);
}





function play() {

}
function init() {
  try {
    settings = JSON.parse(getParam("settings"));
    if (settings) {
      if (settings.lat)
        lat = settings.lat;
      if (settings.lng)
        lng = settings.lng;
      if (settings.city)
        cityName = settings.city;

      if (lat.trim() == "" || lng.trim() == "") {
        lat = "35.6944";
        lng = "51.4215";
        cityName = "تهران";
      }
    }
  } catch (e) { }
  localStorageVaribleName = "weather_data_" + lat + "__" + lng;
  localStorageVaribleName = localStorageVaribleName.replace(".", "_");

  document.getElementById("city_name").innerText = cityName;

  skycons = new Skycons({
    "monochrome": false,
    "colors": {
      "main": "#fff",
      "moon": "#ddd",
      "fog": "#fff",
      "fogbank": "#fff",
      "cloud": "#fff",
      "snow": "#fff",
      "leaf": "#9CCC65",
      "rain": "#fff",
      "sun": "#fff"
    }
  });
  checkCookie(localStorageVaribleName);
  setClock();

}
try {
  onDelayedParamsReady(function () {
    init();
  });
} catch (error) { }



