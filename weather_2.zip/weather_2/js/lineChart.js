function lineChart() {


    const DATA_COUNT = 7;
    const NUMBER_CFG = { count: DATA_COUNT, min: -100, max: 100 };

    const labels = chartTempThreeHours_hours;
    const data = {
        labels: labels,
        datasets: [
            {
                label: "پیش بینی 24 ساعت آینده",
                data: chartTempThreeHours_middle,
                borderColor: 'white',
                backgroundColor: 'white',
                fontsize: 30,
                borderWidth: 2,
                borderRadius: Number.MAX_VALUE,
                borderSkipped: false,
                pointStyle: 'circle',
                pointRadius: 5,
            },

        ]
    };

    const config = {
        type: 'line',
        data: data,
        options: {



            segmentStrokeColor: "transparent",
            responsive: true,
            scales: {
                title: {
                    display: false,
                },

                xAxes: {

                    backdropColor: "white",
                    grid: {
                        offset: true,
                        display: false,
                        drawTicks: true,
                        drawBorder: true,
                        color: 'rgba(255, 255, 255, 0.2)',
                        borderColor: 'rgba(255, 255, 255, 0.2)',
                        borderWidth: 5
                    },
                    ticks: {
                        color: "white",
                        textStrokeColor: "white",


                    }
                },
                yAxes: {

                    backdropColor: "white",
                    grid: {
                        offset: true,
                        display: false,
                        drawTicks: true,
                        drawBorder: true,
                        color: 'rgba(255, 255, 255, 0.2)',
                        borderColor: 'rgba(255, 255, 255, 0.2)',
                        borderWidth: 5
                    },
                    ticks: {
                        color: "white",
                        textStrokeColor: "white",
                        callback: function (value, index, ticks) {
                            return value + "°";
                        },
                    },
                }
            },
            plugins: {
                legend: {
                    labels:
                    {
                        color: 'white',
                        
                        font: {
                            size: 20
                        }
                    },
                    position: 'bottom',
                    display:true,

                   

                },
                
            }
        },
    };

    chart = new Chart("myChart", config);





}
