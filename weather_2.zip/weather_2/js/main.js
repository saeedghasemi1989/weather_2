function getData() {
    $.ajax({
        url: "https://api.openweathermap.org/data/2.5/forecast",
        data: {
            lat: "35.7219",
            lon: "51.3347",
            limit: "5",
            units: "metric",
            appid: "90616faebcb4448df099bf202587a233"
        },
        type: "GET",
        success: function (result) {
            debugger;
            handleData(result)
        },
        error: function (error) {
            alert('error ');
        }
    });


}
function handleData(data) {
    var maxt_1 = -250;
    var mint_1 = 1000;
    var maxt_2 = -250;
    var mint_2 = 1000;
    var maxt_3 = -250;
    var mint_3 = 1000;
    var maxt_4 = -250;
    var mint_4 = 1000;
    var maxt_5 = -250;
    var mint_5 = 1000;

    var d_1 = new Date();
    let nowHours = d_1.getHours();

    var d_2 = new Date();
    d_2.setDate(d_2.getDate() + 1);

    var d_3 = new Date();
    d_3.setDate(d_3.getDate() + 2);

    var d_4 = new Date();
    d_4.setDate(d_4.getDate() + 3);

    var d_5 = new Date();
    d_5.setDate(d_5.getDate() + 4);

    d_1 = d_1.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    d_2 = d_2.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    d_3 = d_3.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    d_4 = d_4.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    d_5 = d_5.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });
    let status1 = null;
    let status2 = null;
    let status3 = null;
    let status4 = null;
    let status5 = null;




    for (let i = 0; i < data.list.length; i++) {
        //date with clock
        let d = new Date(data.list[i].dt_txt);
        //hours at all day
        let itemHours = d.getHours();
        //date
        d = d.toLocaleString(undefined, { year: 'numeric', month: '2-digit', day: '2-digit' });

        let tMin = data.list[i].main.temp_min;
        let tMax = data.list[i].main.temp_max;



        if (d === d_1) {
            //just today
            if (maxt_1 < tMax) {
                maxt_1 = tMax;
            }
            if (mint_1 > tMin) {
                mint_1 = tMin;
            }

            if (itemHours <= nowHours && (itemHours + 3) > nowHours) {
                status1 = data.list[i].weather[0].main;
            }

        }

        if (d === d_2) {
            if (maxt_2 < tMax) {
                maxt_2 = tMax;
            }
            if (mint_2 > tMin) {
                mint_2 = tMin;
            }
           

            if ( itemHours== 9) {
            
                status2 = data.list[i].weather[0].main;
            }
        }

        if (d === d_3) {
            if (maxt_3 < tMax) {
                maxt_3 = tMax;
            }
            if (mint_3 > tMin) {
                mint_3 = tMin;
            }

            if ( itemHours== 9) {
            
                status3 = data.list[i].weather[0].main;
            }
        }

        if (d === d_4) {
            if (maxt_4 < tMax) {
                maxt_4 = tMax;
            }
            if (mint_4 > tMin) {
                mint_4 = tMin;
            }


            if ( itemHours== 9) {
          
                status4 = data.list[i].weather[0].main;
            }
        }

        if (d === d_5) {
            if (maxt_5 < tMax) {
                maxt_5 = tMax;
            }
            if (mint_5 > tMin) {
                mint_5 = tMin;
            }


            if ( itemHours== 9) {
                status5 = data.list[i].weather[0].main;
            }
        }

    }

    document.getElementById("temp1_min").innerHTML = mint_1;
    document.getElementById("temp1_max").innerHTML = maxt_1;
    document.getElementById("status1").innerHTML = status1;


    document.getElementById("temp2_min").innerHTML = mint_2;
    document.getElementById("temp2_max").innerHTML = maxt_2;
    document.getElementById("status2").innerHTML = status2;


    document.getElementById("temp3_min").innerHTML = mint_3;
    document.getElementById("temp3_max").innerHTML = maxt_3;
    document.getElementById("status3").innerHTML = status2;


    document.getElementById("temp4_min").innerHTML = mint_4;
    document.getElementById("temp4_max").innerHTML = maxt_4;
    document.getElementById("status4").innerHTML = status2;


    document.getElementById("temp5_min").innerHTML = mint_5;
    document.getElementById("temp5_max").innerHTML = maxt_5;
    document.getElementById("status5").innerHTML = status2;

}


// init
getData();
