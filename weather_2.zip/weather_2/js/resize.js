


function checkWindowRatio(){
  var screenHeight=screen.height;  //height of browser
  var windowHeight=window.innerHeight; //height of window
  var screenWidth=window.screen.width; //width of browser
  var windowWidth=window.innerWidth; //width of window
  
  var r1=screenHeight/windowHeight //get vertical ratio;
  var r2=screenWidth/windowWidth //get horizontal ratio;
  var m=Math.max(r1, r2);
  return m;
}

function reportWindowSize() {
 if(checkWindowRatio()>1.5)
 {
  var r=(1/checkWindowRatio())*100+"%";
  document.body.style.zoom = r; 
 }
 else{
 reportWindowSize2();  
 }

}
reportWindowSize();


//use in mobile for full screen
function reportWindowSize2() {
const x1 = window.matchMedia('(min-width: 400px)');
const x2 = window.matchMedia('(min-width: 600px)')
const x3 = window.matchMedia('(min-width: 900px)')
const x4 = window.matchMedia('(min-width: 1200px)')

document.body.style.zoom = 0.4; 
if (x1.matches) {
  document.body.style.zoom = 0.4; 
}
if (x2.matches) { 
  document.body.style.zoom = 0.6; 
}
if (x3.matches) {
  document.body.style.zoom = 0.8; 
}
if (x4.matches) {
  document.body.style.zoom = 1; 
}
}









window.onresize = reportWindowSize;